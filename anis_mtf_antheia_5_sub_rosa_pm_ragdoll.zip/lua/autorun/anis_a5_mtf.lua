player_manager.AddValidModel("MTF Antheia-5 Sub Rosa" , "models/anis/antheia5.mdl" ) 
player_manager.AddValidHands( "MTF Antheia-5 Sub Rosa", "models/shrimp_arms/arms/v_arms_gsg9.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "MTF Antheia-5 Sub Rosa", "models/anis/antheia5.mdl" )